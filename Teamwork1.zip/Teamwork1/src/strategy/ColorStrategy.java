package strategy;

import java.awt.Color;

public interface ColorStrategy{
	public Color handle();
}
